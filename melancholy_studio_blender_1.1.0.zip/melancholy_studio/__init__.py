bl_info={'name':'melancholy Studio','author':'melancholy / DragonFF parser contributors','version':(1,1,0),'blender':(4,2,0),'location':'View3D > Sidebar > melancholy','description':'DFF secondary-motion authoring, protected eyes and ASI profile export','category':'Import-Export'}
import bpy,json,base64,uuid,math,struct,shutil,importlib,traceback,threading,queue
from pathlib import Path
import numpy as np
from mathutils import Matrix,Vector
from bpy.props import StringProperty,IntProperty,FloatProperty,EnumProperty,FloatVectorProperty,BoolProperty
from bpy_extras.io_utils import ImportHelper,ExportHelper
from . import studio_io as io
# Blender can retain submodules when replacing/re-enabling an add-on ZIP.
# Reload the pure-Python writer alongside the entry point to keep the API paired.
io=importlib.reload(io)
from . import updater
updater=importlib.reload(updater)

_updates={'busy':False,'message':'','available':None,'restart':False}
_update_results=queue.Queue()

def update_ui(layout):
 box=layout.box();box.label(text='melancholy Studio '+'.'.join(map(str,bl_info['version'])))
 row=box.row();row.enabled=not _updates['busy'] and not _updates['restart'];row.operator('mch.check_update',text='Проверить обновления',icon='FILE_REFRESH')
 if _updates['available'] and not _updates['restart']:row.operator('mch.install_update',text='Установить обновление',icon='IMPORT')
 if _updates['message']:box.label(text=_updates['message'])
 if _updates['restart']:box.label(text='Сохрани проект и перезапусти Blender',icon='INFO')

def _poll_update():
 try:kind,result,error=_update_results.get_nowait()
 except queue.Empty:return .2
 _updates['busy']=False
 if error:_updates['message']='Ошибка обновления: '+str(error)[:150]
 elif kind=='check':
  _updates['available']=result;_updates['message']=('Доступна версия '+'.'.join(map(str,result['version']))) if result else 'Установлена актуальная версия'
 else:_updates.update(restart=True,message='Обновление установлено. Нужен перезапуск.');print('melancholy update backup:',result)
 for window in bpy.context.window_manager.windows:
  for area in window.screen.areas:area.tag_redraw()
 return None

def _start_update(kind):
 if _updates['busy'] or _updates['restart']:return False
 if hasattr(bpy.app,'online_access') and not bpy.app.online_access:raise ValueError('Включи Allow Online Access в настройках Blender')
 _updates.update(busy=True,message='Проверяю обновления…' if kind=='check' else 'Скачиваю и устанавливаю…')
 current=bl_info['version'];blender=bpy.app.version;info=_updates['available'];directory=Path(__file__).resolve().parent
 def worker():
  try:
   result=updater.check(current,blender) if kind=='check' else updater.install(directory,updater.download(info),info)
   _update_results.put((kind,result,None))
  except Exception as e:_update_results.put((kind,None,e))
 threading.Thread(target=worker,daemon=True).start();bpy.app.timers.register(_poll_update,first_interval=.2);return True

class MCHUpdatePreferences(bpy.types.AddonPreferences):
 bl_idname=__package__
 auto_check:BoolProperty(name='Проверять обновления при запуске Blender',default=True)
 def draw(self,context):self.layout.prop(self,'auto_check');update_ui(self.layout)

class MCHCheckUpdate(bpy.types.Operator):
 bl_idname='mch.check_update';bl_label='Check melancholy updates'
 def execute(self,context):
  try:_start_update('check');return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}

class MCHInstallUpdate(bpy.types.Operator):
 bl_idname='mch.install_update';bl_label='Install melancholy update'
 def execute(self,context):
  if not _updates['available']:self.report({'ERROR'},'Сначала проверь обновления');return {'CANCELLED'}
  try:_start_update('install');return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}

def _automatic_update_check():
 addon=bpy.context.preferences.addons.get(__package__)
 if addon and addon.preferences.auto_check and not bpy.app.background:
  try:_start_update('check')
  except Exception:pass
 return None

def active(context):
 o=context.object
 if not o or o.type!='MESH' or 'mch_meta' not in o:raise ValueError('Select the imported melancholy mesh')
 return o
def meta(o):return json.loads(o['mch_meta'])
def save_meta(o,d):o['mch_meta']=json.dumps(d)
def group(o,name):return o.vertex_groups.get(name) or o.vertex_groups.new(name=name)
def weights(o,name):
 out=np.zeros(len(o.data.vertices));g=o.vertex_groups.get(name)
 if g:
  for v in o.data.vertices:
   for e in v.groups:
    if e.group==g.index:out[v.index]=e.weight
 return out
def set_weights(o,name,values):
 g=group(o,name);batches={}
 for i,w in enumerate(values):
  if w>0:batches.setdefault(float(w),[]).append(i)
 for w,indices in batches.items():g.add(indices,w,'REPLACE')
def source(o):return base64.b64decode(bpy.data.texts[o['mch_source']].as_string())
def encoded(data):
 value=base64.b64encode(data).decode();return '\n'.join(value[i:i+120] for i in range(0,len(value),120))
def canonical(v):
 # Derive a display transform only; the exported DFF retains its original axes.
 head=np.linalg.inv(np.array(v).T)[:3,3];C=np.array([[0,0,-1],[0,1,0],[1,0,0]]) if abs(head[0])>abs(head[2]) else np.eye(3)
 return C
def import_model(path,profile=None,txd=None):
 d,c,g,s=io.read_dff(path);n=len(g.vertices);v=np.array(g.vertices);C=canonical(s.bone_matrices[5]);name=Path(path).stem
 channels=[dict(mode=2,bone=-1,anchor=5,motion=[45,9,.8,.2,1.5,.5],pivot=[0,0,0],tip=[0,0,-.3],name='Channel '+str(i+1)) for i in range(16)]
 tags=next(([b.id for b in sorted(f.bone_data.bones,key=lambda b:b.index)] for f in c.frame_list if f.bone_data and f.bone_data.bones),io.TAGS)
 if len(tags)!=32:raise ValueError('Expected 32 hierarchy tags')
 doc=dict(key='model_'+uuid.uuid4().hex[:20],name=name,axes=C.tolist(),centers=[[-.08,-.08,.42],[.08,-.08,.42],[-.08,.09,0],[.08,.09,0]],channels=channels,tags=tags,head=tags.index(5),breast_anchor=tags.index(3),butt_anchor=tags.index(1),base=io.default_base().hex(),flags=31)
 for channel in channels:channel['anchor']=doc['head'];channel['pivot']=np.linalg.inv(np.array(s.bone_matrices[doc['head']]).T)[:3,3].tolist();channel['tip']=(np.array([0,0,-.3])@C).tolist()
 doc['centers']=(np.array(doc['centers'])@C).tolist()
 rows=None
 if profile:
  doc,rows,nv,nt=io.read_profile(profile)
  if nv!=n or nt!=len(g.triangles):raise ValueError('Profile does not match final DFF. Reimport the correct pair')
  data=Path(profile).read_bytes()
  if struct.unpack_from('<I',data,4)[0]==2:
   expected=np.frombuffer(data,dtype='<f4',count=n*3,offset=io.HEADER+n*20).reshape(n,3)
   if np.linalg.norm(v-expected,axis=1).max()>2e-5:raise ValueError('DFF basis differs from profile. Import the final DFF without the old adjacent profile')
  if np.max(np.linalg.norm(v[rows['index']]-rows['values'][:,:3],axis=1))>2e-5:raise ValueError('Profile vertex order / positions differ. Uncheck adjacent profile to author the final DFF from scratch')
  C=np.array(doc['axes'])
 tri=[[t.a,t.b,t.c] for t in g.triangles];mesh=bpy.data.meshes.new(name);mesh.from_pydata((v@C.T).tolist(),[],tri);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 raw=bpy.data.texts.new('MCH_SOURCE_'+doc['key']);raw.write(encoded(Path(path).read_bytes()));o['mch_source']=raw.name;o['mch_triangles']=json.dumps(tri);o['mch_count']=n;o['mch_stem']=Path(path).stem
 images={}
 txd=Path(txd) if txd else Path(path).with_suffix('.txd')
 if txd.exists():
  from .gtaLib.txd import txd as TXD,TextureNative
  rawtex=txd.read_bytes();texlist=[];pos=12
  while pos+12<=len(rawtex):
   typ,size,ver=struct.unpack_from('<III',rawtex,pos);end=pos+12+size
   if end>len(rawtex):raise ValueError('Truncated TXD')
   if typ==0x15:
    at=pos+12;kind,sz,_=struct.unpack_from('<III',rawtex,at)
    if kind==1:texlist.append(TextureNative.from_mem(rawtex[at+12:at+12+sz]))
   pos=end
  for t in texlist:
   try:
    key=t.name.decode() if isinstance(t.name,bytes) else t.name;im=bpy.data.images.new(key,width=t.width,height=t.height,alpha=True);arr=np.frombuffer(bytes(t.to_rgba()),dtype=np.uint8).reshape(t.height,t.width,4)[::-1].astype(np.float32)/255;im.pixels.foreach_set(arr.ravel());im.pack();images[key]=im
   except Exception as e:print('TXD texture:',e)
  packed=bpy.data.texts.new('MCH_TXD_'+doc['key']);packed.write(encoded(rawtex));o['mch_txd']=packed.name
 for mat in g.materials:
  key=mat.textures[0].name if mat.textures else '';m=bpy.data.materials.new(key or 'Material');m.use_nodes=True;nodes=m.node_tree.nodes;bsdf=nodes.get('Principled BSDF');bsdf.inputs['Roughness'].default_value=.75
  if key in images:
   tex=nodes.new('ShaderNodeTexImage');tex.image=images[key];m.node_tree.links.new(tex.outputs['Color'],bsdf.inputs['Base Color']);m.node_tree.links.new(tex.outputs['Alpha'],bsdf.inputs['Alpha'])
  else:bsdf.inputs['Base Color'].default_value=tuple(x/255 for x in mat.color)
  m.use_backface_culling=True;mesh.materials.append(m)
 uv=mesh.uv_layers.new(name='UVMap')
 if g.uv_layers:
  for loop in mesh.loops:a,b=g.uv_layers[0][loop.vertex_index];uv.data[loop.index].uv=(a,1-b)
 for poly,t in zip(mesh.polygons,g.triangles):poly.material_index=t.material;poly.use_smooth=True
 ids,w=io.normalize(s.vertex_bone_indices,s.vertex_bone_weights)
 doc['unused_slots']=[i for i in io.SPARE if not ((ids==i)&(w>1e-7)).any()]
 for j in range(32):set_weights(o,'SA_%02d'%j,np.sum(w*(ids==j),axis=1))
 for name in ['MCH_Breast_L','MCH_Breast_R','MCH_Butt_L','MCH_Butt_R','MCH_Cheek','MCH_ProtectEyes']+['MCH_%02d'%i for i in range(16)]:group(o,name)
 o.shape_key_add(name='Basis');o.shape_key_add(name='MCH_Blink');o.shape_key_add(name='MCH_Squint');o.shape_key_add(name='MCH_Preview')
 if rows is not None:
  a=rows['index'];q=rows['values'];basis=np.array([o.shape_key_add]) if False else np.array([x.co[:] for x in o.data.vertices])
  for name,start in [('MCH_Blink',3),('MCH_Squint',6)]:
   pts=basis.copy();pts[a]+=q[:,start:start+3]@C.T;o.data.shape_keys.key_blocks[name].data.foreach_set('co',pts.ravel())
  for j,name in enumerate(['MCH_Breast_L','MCH_Breast_R','MCH_Butt_L','MCH_Butt_R']):z=np.zeros(n);z[a]=q[:,15+j];set_weights(o,name,z)
  for j in range(16):z=np.zeros(n);z[a]=q[:,19+j];set_weights(o,'MCH_%02d'%j,z)
  for name,col in [('MCH_Cheek',35),('MCH_ProtectEyes',36)]:z=np.zeros(n);z[a]=q[:,col];set_weights(o,name,z)
 # A real 32-bone armature permits weight-paint / Pose Mode checks.
 arm=bpy.data.armatures.new(name+'_SA');rig=bpy.data.objects.new(name+'_SA',arm);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);o.select_set(False);bpy.ops.object.mode_set(mode='EDIT')
 for i in range(32):
  bind=np.linalg.inv(np.array(s.bone_matrices[i]).T);bone=arm.edit_bones.new('SA_%02d'%i);bone.head=Vector(C@bind[:3,3]);axis=C@bind[:3,2];bone.tail=bone.head+Vector(axis)*.04
 for fi,frame in enumerate(c.frame_list):
  if not frame.bone_data or frame.bone_data.header.id not in tags:continue
  child=tags.index(frame.bone_data.header.id);parent=frame.parent
  while parent>=0:
   ancestor=c.frame_list[parent]
   if ancestor.bone_data and ancestor.bone_data.header.id in tags:
    slot=tags.index(ancestor.bone_data.header.id)
    if slot!=child:arm.edit_bones['SA_%02d'%child].parent=arm.edit_bones['SA_%02d'%slot]
    break
   parent=ancestor.parent
 bpy.ops.object.mode_set(mode='OBJECT');rig.select_set(False);o.select_set(True);bpy.context.view_layer.objects.active=o;mod=o.modifiers.new('MCH skeletal preview','ARMATURE');mod.object=rig;o['mch_rig']=rig.name;o['mch_rest']=json.dumps([(list(b.head_local),list(b.tail_local)) for b in arm.bones])
 for i,ch in enumerate(doc['channels']):
  pivot=bpy.data.objects.new('MCH_Pivot_%02d'%i,None);bpy.context.collection.objects.link(pivot);pivot.parent=o;pivot.location=C@ch['pivot'];pivot.empty_display_type='SPHERE';pivot.empty_display_size=.015
  tip=bpy.data.objects.new('MCH_Tip_%02d'%i,None);bpy.context.collection.objects.link(tip);tip.parent=pivot;tip.location=C@ch['tip'];tip.empty_display_type='PLAIN_AXES';tip.empty_display_size=.025;ch['pivot_object']=pivot.name;ch['tip_object']=tip.name;pivot.hide_viewport=ch['mode']==2;tip.hide_viewport=ch['mode']==2
 doc['body_center_objects']=[]
 for label,position in zip(('Breast_L','Breast_R','Butt_L','Butt_R'),doc['centers']):
  center=bpy.data.objects.new('MCH_Center_'+label,None);bpy.context.collection.objects.link(center);center.parent=o;center.location=C@position;center.empty_display_type='SPHERE';center.empty_display_size=.025;doc['body_center_objects'].append(center.name)
 settings={'breast':list(struct.unpack_from('<I8f',bytes.fromhex(doc['base']),52)),'butt':list(struct.unpack_from('<I8f',bytes.fromhex(doc['base']),88)),'eyes':list(struct.unpack_from('<3I10f',bytes.fromhex(doc['base']),124)),'blush':list(struct.unpack_from('<I7f',bytes.fromhex(doc['base']),176)),'centers':doc['centers'],'head':doc['head'],'breast_anchor':doc['breast_anchor'],'butt_anchor':doc['butt_anchor']}
 settings_text=bpy.data.texts.new('MCH_Settings_'+doc['key']);settings_text.write(json.dumps(settings,indent=2));o['mch_settings']=settings_text.name
 save_meta(o,doc);channel_changed(None,bpy.context);return o
def gather(o):
 o.update_from_editmode();bpy.context.view_layer.update();d=meta(o);C=np.array(d['axes']);n=len(o.data.vertices)
 settings=json.loads(bpy.data.texts[o['mch_settings']].as_string());base=bytearray.fromhex(d['base'])
 for key,at,fmt,ints in [('breast',52,'<I8f',1),('butt',88,'<I8f',1),('eyes',124,'<3I10f',3),('blush',176,'<I7f',1)]:
  vals=settings[key];struct.pack_into(fmt,base,at,*[int(x) if i<ints else float(x) for i,x in enumerate(vals)])
 d['base']=base.hex()
 for key in ('centers','head','breast_anchor','butt_anchor'):d[key]=settings[key]
 center_objects=[bpy.data.objects.get(n) for n in d.get('body_center_objects',[])]
 if len(center_objects)==4 and all(center_objects):d['centers']=[(np.array(o.matrix_world.inverted()@a.matrix_world.translation)@C).tolist() for a in center_objects]
 if not n or n>65535:raise ValueError('DFF needs 1..65535 vertices before UV seam splitting')
 if any(m.type!='ARMATURE' or m.name!='MCH skeletal preview' for m in o.modifiers):raise ValueError('Bake model modifiers in the final DFF before physics authoring')
 rig=bpy.data.objects.get(o.get('mch_rig',''))
 if rig:
  actual=[(list(b.head_local),list(b.tail_local)) for b in rig.data.bones]
  if not np.allclose(np.array(actual),np.array(json.loads(o['mch_rest'])),atol=1e-6):raise ValueError('Rest skeleton edited. Finish skeletal changes in DragonFF, reimport final DFF')
 keys=o.data.shape_keys.key_blocks;v=np.array([x.co[:] for x in keys['Basis'].data])@C;blink=(np.array([x.co[:] for x in keys['MCH_Blink'].data])@C)-v;squint=(np.array([x.co[:] for x in keys['MCH_Squint'].data])@C)-v
 body=np.column_stack([weights(o,k) for k in ('MCH_Breast_L','MCH_Breast_R','MCH_Butt_L','MCH_Butt_R')]);hair=np.column_stack([weights(o,'MCH_%02d'%i) for i in range(16)]);protect=weights(o,'MCH_ProtectEyes');cheek=weights(o,'MCH_Cheek')
 ids=[];ws=[]
 for vi in range(n):
  entries=[]
  for e in o.data.vertices[vi].groups:
   name=o.vertex_groups[e.group].name
   if name.startswith('SA_') and e.weight>1e-7:entries.append((int(name[3:]),e.weight))
  if not 1<=len(entries)<=4:raise ValueError('Vertex %d needs 1..4 skeletal weights; physics groups do not count'%vi)
  ids.append([a for a,b in entries]+[0]*(4-len(entries)));ws.append([b for a,b in entries]+[0]*(4-len(entries)))
 for ch in d['channels']:
  po=bpy.data.objects.get(ch.get('pivot_object',''));ti=bpy.data.objects.get(ch.get('tip_object',''))
  if po and ti:
   inv=o.matrix_world.inverted();a=inv@po.matrix_world.translation;b=inv@ti.matrix_world.translation;ch['pivot']=(np.array(a)@C).tolist();ch['tip']=((np.array(b)-a)@C).tolist()
 o.data.calc_loop_triangles()
 return d,v,np.array([list(t.vertices) for t in o.data.loop_triangles]),np.array(ids),np.array(ws),blink,squint,body,hair,cheek,protect
def rebuild_export_mesh(o,args):
 # DFF has per-vertex UVs: split Blender UV seams and copy all weights/morphs.
 d,v,tri,ids,w,*fields=args;mesh=o.data
 original=io.dff();original.load_memory(source(o));g=original.clumps[0].geometry_list[0]
 if len(mesh.uv_layers)!=len(g.uv_layers):raise ValueError('Keep the original number of UV maps for the embedded materials')
 if len(mesh.materials)!=len(g.materials):raise ValueError('Material slots must match the embedded DFF; new material creation is not supported')
 mapping={};indices=[];outuv=[];faces=[];materials=[]
 for t in mesh.loop_triangles:
  poly=mesh.polygons[t.polygon_index]
  if poly.material_index>=len(g.materials):raise ValueError('Invalid material slot')
  face=[]
  for vi,li in zip(t.vertices,t.loops):
   uv=tuple(float(x) for layer in mesh.uv_layers for x in (layer.data[li].uv.x,1-layer.data[li].uv.y))
   key=(int(vi),struct.pack('<%df'%len(uv),*uv))
   if key not in mapping:mapping[key]=len(indices);indices.append(int(vi));outuv.append(uv)
   face.append(mapping[key])
  faces.append(face);materials.append(poly.material_index)
 if not faces or len(indices)>65535:raise ValueError('DFF needs faces and at most 65535 vertices after UV seam splitting')
 ix=np.array(indices);faces=np.array(faces,dtype=np.int32)
 uv=np.asarray(outuv,dtype='<f4').reshape(len(ix),len(mesh.uv_layers),2).transpose(1,0,2)
 # Old source prelighting cannot be indexed by a newly edited topology.
 colors=np.full((len(ix),4),255,dtype=np.uint8)
 return (d,v[ix],faces,ids[ix],w[ix],*[x[ix] for x in fields]),(faces,np.array(materials),uv,colors,io.normals(v,tri)[ix])

def export_model(o,path):
 # Mesh UV collections are empty while their live BMesh owns Edit Mode data.
 # Flush by leaving that mode, then restore the artist's mode on every exit.
 editing=o.mode=='EDIT'
 if editing:
  if bpy.context.view_layer.objects.active!=o:raise ValueError('Make the exported mesh active before exporting from Edit Mode')
  bpy.ops.object.mode_set(mode='OBJECT')
 try:return _export_model_object_mode(o,path)
 finally:
  if editing:bpy.ops.object.mode_set(mode='EDIT')

def _export_model_object_mode(o,path):
 args=gather(o);topology=None
 if len(o.data.vertices)!=o['mch_count'] or [list(p.vertices) for p in o.data.polygons]!=json.loads(o['mch_triangles']):args,topology=rebuild_export_mesh(o,args)
 d,v,tri,ids,w,*_=args;path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 raw=io.patch_dff(source(o),v,topology[4] if topology is not None else io.normals(v,tri),ids,w,topology)
 temporary=path.with_suffix('.mchmodel.tmp');io.write_profile(temporary,*args)
 dffpath=path.with_suffix('.dff');dfftmp=path.with_suffix('.dff.tmp');dfftmp.write_bytes(raw);io.read_dff(dfftmp);stages=[(dfftmp,dffpath)]
 if o.get('mch_txd'):
  txd=path.with_suffix('.txd');tmp=path.with_suffix('.txd.tmp');tmp.write_bytes(base64.b64decode(bpy.data.texts[o['mch_txd']].as_string()));stages.append((tmp,txd))
 stages.append((temporary,path));previous={dest:dest.read_bytes() if dest.exists() else None for _,dest in stages}
 try:
  for tmp,dest in stages:
   if dest.exists():shutil.copy2(dest,dest.with_name(dest.name+'.previous'))
   tmp.replace(dest)
 except Exception:
  for dest,data in previous.items():
   if data is not None:dest.write_bytes(data)
   elif dest.exists():dest.unlink()
  raise
 return path
class MCHImport(bpy.types.Operator,ImportHelper):
 bl_idname='mch.import_dff';bl_label='Import final DFF';filename_ext='.dff';filter_glob:StringProperty(default='*.dff',options={'HIDDEN'})
 use_profile:BoolProperty(name='Use adjacent .mchmodel',default=True)
 def execute(self,ctx):
  try:
   p=Path(self.filepath);profile=p.with_suffix('.mchmodel');import_model(p,profile if self.use_profile and profile.exists() else None);return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}
class MCHExport(bpy.types.Operator,ExportHelper):
 bl_idname='mch.export';bl_label='Export DFF + TXD + profile';filename_ext='.mchmodel';filter_glob:StringProperty(default='*.mchmodel',options={'HIDDEN'})
 def execute(self,ctx):
  try:export_model(active(ctx),self.filepath);self.report({'INFO'},'DFF, TXD and profile exported. Refresh model list in game.');return {'FINISHED'}
  except Exception as e:
   detail=traceback.format_exc();print(detail);log=bpy.data.texts.get('MCH_LAST_EXPORT_ERROR') or bpy.data.texts.new('MCH_LAST_EXPORT_ERROR');log.clear();log.write('Blender '+bpy.app.version_string+' / melancholy Studio '+str(bl_info['version'])+'\n'+detail);self.report({'ERROR'},str(e)+' (details: Text Editor > MCH_LAST_EXPORT_ERROR)');return {'CANCELLED'}
class MCHApply(bpy.types.Operator):
 bl_idname='mch.apply_channel';bl_label='Apply channel fields'
 def execute(self,ctx):
  try:
   o=active(ctx);d=meta(o);i=ctx.scene.mch_channel;c=d['channels'][i];c.update(name=ctx.scene.mch_channel_name,mode=int(ctx.scene.mch_mode),bone=ctx.scene.mch_bone,anchor=ctx.scene.mch_anchor,motion=list(ctx.scene.mch_motion));d['name']=ctx.scene.mch_name;save_meta(o,d)
   for key in ('pivot_object','tip_object'):
    ob=bpy.data.objects.get(c.get(key,''))
    if ob:ob.hide_viewport=c['mode']==2
   return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}
class MCHSelect(bpy.types.Operator):
 bl_idname='mch.paint';bl_label='Paint selected channel'
 def execute(self,ctx):
  try:o=active(ctx);o.vertex_groups.active_index=group(o,'MCH_%02d'%ctx.scene.mch_channel).index;bpy.ops.object.mode_set(mode='WEIGHT_PAINT');return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}
class MCHProtect(bpy.types.Operator):
 bl_idname='mch.protect';bl_label='Protect selected eye vertices'
 def execute(self,ctx):
  try:
   o=active(ctx);o.update_from_editmode();ids=[v.index for v in o.data.vertices if v.select];mode=o.mode
   if mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
   if not ids:raise ValueError('Select eye / lash vertices in Edit Mode first')
   group(o,'MCH_ProtectEyes').add(ids,1,'REPLACE')
   for i in range(16):group(o,'MCH_%02d'%i).remove(ids)
   if mode=='EDIT':bpy.ops.object.mode_set(mode='EDIT')
   self.report({'INFO'},'Selected vertices protected; channel weights cleared');return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}
class MCHPreview(bpy.types.Operator):
 bl_idname='mch.preview';bl_label='Update bend preview'
 def execute(self,ctx):
  try:
   o=active(ctx);d=meta(o);i=ctx.scene.mch_channel;c=d['channels'][i];keys=o.data.shape_keys.key_blocks;basis=np.array([p.co[:] for p in keys['Basis'].data]);pivot=bpy.data.objects[c['pivot_object']].location;axis=Vector((0,1,0));r=np.array(Matrix.Rotation(math.radians(ctx.scene.mch_angle),3,axis));w=weights(o,'MCH_%02d'%i)*(1-weights(o,'MCH_ProtectEyes'));v=basis+((basis-np.array(pivot))@r.T-(basis-np.array(pivot)))*w[:,None];keys['MCH_Preview'].data.foreach_set('co',v.ravel());keys['MCH_Preview'].value=1;return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}
class MCHSettings(bpy.types.Operator):
 bl_idname='mch.settings';bl_label='Edit all preset defaults (JSON)'
 def execute(self,ctx):
  try:o=active(ctx);ctx.area.type='TEXT_EDITOR';ctx.area.spaces.active.text=bpy.data.texts[o['mch_settings']];return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}
class MCHNewID(bpy.types.Operator):
 bl_idname='mch.new_id';bl_label='New independent profile ID'
 def execute(self,ctx):
  try:o=active(ctx);d=meta(o);d['key']='model_'+uuid.uuid4().hex[:20];save_meta(o,d);self.report({'INFO'},'New ID assigned. Export under a new filename.');return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}
class MCHScan(bpy.types.Operator):
 bl_idname='mch.scan_bones';bl_label='Scan spare bones'
 def execute(self,ctx):
  try:o=active(ctx);d=meta(o);d['unused_slots']=[i for i in io.SPARE if weights(o,'SA_%02d'%i).max()==0];save_meta(o,d);return {'FINISHED'}
  except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}
def channel_changed(self,ctx):
 try:
  o=active(ctx);d=meta(o);c=d['channels'][ctx.scene.mch_channel];ctx.scene.mch_channel_name=c['name'];ctx.scene.mch_mode=str(c['mode']);ctx.scene.mch_bone=c['bone'];ctx.scene.mch_anchor=c['anchor'];ctx.scene.mch_name=d['name'];ctx.scene.mch_motion=c['motion']
 except Exception:pass
class MCHPanel(bpy.types.Panel):
 bl_label='melancholy Studio';bl_idname='MCH_PT_studio';bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='melancholy'
 def draw(self,ctx):
  l=self.layout;s=ctx.scene;update_ui(l);l.operator('mch.import_dff');o=ctx.object
  if not o or 'mch_meta' not in o:return
  l.prop(s,'mch_name');l.operator('mch.new_id');l.prop(s,'mch_channel');l.prop(s,'mch_channel_name');l.prop(s,'mch_mode');l.prop(s,'mch_bone');l.prop(s,'mch_anchor');l.prop(s,'mch_motion');l.label(text='K / damping / inertia / drag / wind / angle(rad)');l.operator('mch.apply_channel');l.operator('mch.paint');l.operator('mch.protect');l.prop(s,'mch_angle');l.operator('mch.preview');l.operator('mch.settings');l.operator('mch.export');l.label(text='Edit MCH_Blink / MCH_Squint shape keys');l.label(text='Pivot / Tip empties set channel rotation');l.label(text='Only existing 32 SA bones; 4 weights/vertex')
  d=meta(o);l.operator('mch.scan_bones');l.label(text='Unused spare slots (last scan): '+', '.join(str(i) for i in d.get('unused_slots',[])))
classes=(MCHUpdatePreferences,MCHCheckUpdate,MCHInstallUpdate,MCHImport,MCHExport,MCHApply,MCHSelect,MCHProtect,MCHPreview,MCHSettings,MCHNewID,MCHScan,MCHPanel)
def export_menu(self,context):
 self.layout.operator("mch.export",text="melancholy DFF + TXD + profile (.mchmodel)")

def register():
 bpy.types.TOPBAR_MT_file_export.append(export_menu)
 for c in classes:bpy.utils.register_class(c)
 bpy.app.timers.register(_automatic_update_check,first_interval=2)
 S=bpy.types.Scene;S.mch_channel=IntProperty(name='Channel 0..15',min=0,max=15,update=channel_changed);S.mch_channel_name=StringProperty(name='Channel name',default='Channel 1',maxlen=31);S.mch_name=StringProperty(name='Model menu name',default='My model',maxlen=95);S.mch_mode=EnumProperty(name='Mode',items=[('0','Vertex weights','CPU masks, no spare bone needed'),('1','Existing bone','Isolated spare bone only'),('2','Disabled','No motion')],default='0');S.mch_bone=IntProperty(name='Bone slot',default=6,min=0,max=31);S.mch_anchor=IntProperty(name='Anchor slot',default=5,min=0,max=31);S.mch_angle=FloatProperty(name='Preview bend, degrees',default=15,min=-40,max=40);S.mch_motion=FloatVectorProperty(name='Channel physics',size=6,default=(45,9,.8,.2,1.5,.5))
def unregister():
 if bpy.app.timers.is_registered(_automatic_update_check):bpy.app.timers.unregister(_automatic_update_check)
 if bpy.app.timers.is_registered(_poll_update):bpy.app.timers.unregister(_poll_update)
 bpy.types.TOPBAR_MT_file_export.remove(export_menu)
 for c in reversed(classes):bpy.utils.unregister_class(c)
 for p in ('mch_channel','mch_channel_name','mch_name','mch_mode','mch_bone','mch_anchor','mch_angle','mch_motion'):delattr(bpy.types.Scene,p)
