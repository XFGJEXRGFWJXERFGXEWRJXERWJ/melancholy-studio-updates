# DragonFF material integration

Material UI, DFFMaterialProps, material_helper import/export methods and
material generation are extracted from https://github.com/Parik27/DragonFF .
Copyright (C) 2019 Parik and DragonFF contributors. GNU GPL v3 or later.
See LICENSE. Full adapted source is included in this addon archive.

Changes: unique panel/property class names, registration coexistence, preserved
32-bone DFF bridge, migration of old projects, vertex attribute seam expansion,
and OTA packaging. Generated material logic otherwise follows DragonFF.

Original files (local upstream snapshot SHA-256):
- gui/dff_menus.py: `2f1271d473457d6abc331f0032ae12aebe9e3c95d2fc1ab1556cc88d33e663f9`
- ops/dff_exporter.py: `7b46f7bc6f744ef430ecf6b956f9820aebdead75771a46d277a2cc095f06f9fd`
- ops/importer_common.py: `0f544f1771440be296180b438336a45b93ac66c71d579733a567a3b2eac54c61`
- ops/exporter_common.py: `95c95e8c7508742b554871f5381659e9cd0ac8495c42a242f62f9e78068d396a`
