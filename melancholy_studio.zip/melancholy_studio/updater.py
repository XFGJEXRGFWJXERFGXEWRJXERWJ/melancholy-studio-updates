"""Small HTTPS-only update client. No Blender API, credentials or model uploads."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
import time
import urllib.request
from urllib.parse import urlsplit
import zipfile

REPOSITORY = 'XFGJEXRGFWJXERFGXEWRJXERWJ/melancholy-studio-updates'
BASE_URL = 'https://raw.githubusercontent.com/' + REPOSITORY + '/main/'
MANIFEST_URL = BASE_URL + 'update.json'
RAW_ROOT = 'https://raw.githubusercontent.com/' + REPOSITORY + '/'
REF_URL = 'https://api.github.com/repos/' + REPOSITORY + '/git/ref/heads/main'
MAX_ARCHIVE = 4 * 1024 * 1024
MAX_UNPACKED = 20 * 1024 * 1024


def trusted_url(url):
    if not isinstance(url,str):return False
    parsed=urlsplit(url)
    if parsed.scheme!='https' or parsed.username or parsed.password or parsed.fragment:return False
    if url.split('?',1)[0]==REF_URL:return True
    if not url.startswith(RAW_ROOT):return False
    path=parsed.path[len('/'+REPOSITORY+'/'):]
    return bool(re.fullmatch(r'(?:main|[0-9a-f]{40})/[A-Za-z0-9_.-]+',path))


def fetch(url, limit):
    # All downloads are pinned to this update repository. TLS verification stays on.
    if not trusted_url(url):
        raise ValueError('Update URL is outside the configured repository')
    req = urllib.request.Request(url, headers={'User-Agent': 'melancholy-Studio-Updater', 'Accept':'application/vnd.github+json', 'Cache-Control': 'no-cache', 'Pragma':'no-cache'})
    with urllib.request.urlopen(req, timeout=12) as response:
        if not trusted_url(response.geturl()):
            raise ValueError('Unexpected update redirect')
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError('Update download exceeds size limit')
    return data


def version(value):
    if not isinstance(value, (list, tuple)) or len(value) != 3 or any(type(i) is not int or not 0 <= i <= 9999 for i in value):
        raise ValueError('Invalid update version')
    return tuple(value)


def validate_manifest(info):
    if not isinstance(info, dict) or info.get('schema') != 1 or info.get('addon') != 'melancholy_studio':
        raise ValueError('This is not a melancholy Studio update manifest')
    version(info.get('version'))
    if not re.fullmatch(r'[0-9a-f]{64}', info.get('sha256', '')):
        raise ValueError('Missing update checksum')
    if not isinstance(info.get('url'), str) or not info['url'].startswith(BASE_URL):
        raise ValueError('Untrusted update URL')
    if not isinstance(info.get('notes', ''), str) or len(info.get('notes', '')) > 2000:
        raise ValueError('Invalid release notes')
    version(info.get('blender_min', [4, 2, 0]))
    return info


def check(current, blender_version):
    # Branch-based raw URLs can return an obsolete manifest. Resolve the current
    # branch through the GitHub API, then pin both downloads to that exact commit.
    ref=json.loads(fetch(REF_URL+'?mch='+str(time.time_ns()),32*1024))
    commit=ref.get('object',{}).get('sha')
    if ref.get('ref')!='refs/heads/main' or ref.get('object',{}).get('type')!='commit' or not isinstance(commit,str) or not re.fullmatch('[0-9a-f]{40}',commit):
        raise ValueError('Не удалось подтвердить текущую версию GitHub')
    info = validate_manifest(json.loads(fetch(RAW_ROOT+commit+'/update.json', 32 * 1024)))
    info['_commit']=commit
    if version(info.get('blender_min', [4, 2, 0])) > tuple(blender_version):
        raise ValueError('This update needs a newer Blender version')
    return info if version(info['version']) > tuple(current) else None


def archive_files(data, info):
    validate_manifest(info)
    if len(data) > MAX_ARCHIVE or hashlib.sha256(data).hexdigest() != info['sha256']:
        raise ValueError('Update checksum mismatch; installed add-on was not changed')
    files = {}
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        if len(archive.infolist()) > 512:
            raise ValueError('Too many update files')
        total = 0
        for item in archive.infolist():
            name = item.filename
            path = PurePosixPath(name)
            if '\\' in name or path.is_absolute() or '..' in path.parts or not path.parts or path.parts[0] != 'melancholy_studio':
                raise ValueError('Unsafe path inside update archive')
            if item.is_dir():
                continue
            if len(path.parts) < 2 or name in files or item.flag_bits & 1 or (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Unsafe or duplicate update entry')
            total += item.file_size
            if total > MAX_UNPACKED:
                raise ValueError('Unpacked update exceeds size limit')
            files[name] = archive.read(item)
    for required in ('__init__.py', 'studio_io.py', 'updater.py', 'LICENSE', 'gtaLib/dff.py'):
        if 'melancholy_studio/' + required not in files:
            raise ValueError('Incomplete add-on update: ' + required)
    for name, value in files.items():
        if name.endswith('.py'):
            compile(value, name, 'exec')
    tree = ast.parse(files['melancholy_studio/__init__.py'])
    meta = next((ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'bl_info' for t in n.targets)), None)
    if not meta or version(meta['version']) != version(info['version']):
        raise ValueError('Archive and manifest versions differ')
    return files


def download(info):
    validate_manifest(info)
    commit=info.get('_commit')
    if not isinstance(commit,str) or not re.fullmatch('[0-9a-f]{40}',commit):raise ValueError('Сначала проверь обновления: отсутствует проверенный коммит')
    data = fetch(RAW_ROOT+commit+'/'+info['url'][len(BASE_URL):], MAX_ARCHIVE)
    archive_files(data, info)
    return data


def install(directory, data, info):
    """Stage files, keep a backup, then swap directories; restore on failure."""
    files = archive_files(data, info)
    target = Path(directory).resolve()
    if target.name != 'melancholy_studio' or not (target / '__init__.py').is_file():
        raise ValueError('Unexpected installed add-on directory')
    cache = target.parent / '.melancholy_update_cache'
    cache.mkdir(exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix='update-', dir=cache))
    staged = work / 'melancholy_studio'
    backup = work / 'previous'
    for name, content in files.items():
        dest = work.joinpath(*PurePosixPath(name).parts)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(content)
    moved = False
    try:
        os.replace(target, backup)
        moved = True
        os.replace(staged, target)
    except Exception:
        if moved:
            os.replace(backup, target)
        raise
    return str(backup)
