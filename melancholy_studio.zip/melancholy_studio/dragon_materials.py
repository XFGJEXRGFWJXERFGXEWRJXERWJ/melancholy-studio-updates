# GTA DragonFF - Blender scripts to edit basic GTA formats
# Copyright (C) 2019  Parik

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.



# Material system extracted from Parik27/DragonFF; integration namespace and registration adapted.
import bpy, mathutils, copy, re
from bpy_extras import anim_utils
from .gtaLib import dff
from .gtaLib.dff import strlen
from .gtaLib.data import presets


def clear_extension(string):
    k = string.rfind('.')
    return string if k < 0 else string[:k]

def extract_texture_info_from_name(name):
    """Extract texture info from TXD import naming pattern"""
    pattern = r'^[^/]+\.txd/([^/]+)/(\d+)$'
    match = re.match(pattern, name)
    if match:
        return match.group(1), int(match.group(2))
    else:
        return name, 0

texture_filters_items = (
    ("0", "Disabled", ""),
    ("1", "Nearest", "Point sampled"),
    ("2", "Linear", "Bilinear"),
    ("3", "Mip Nearest", "Point sampled per pixel MipMap"),
    ("4", "Mip Linear", "Bilinear per pixel MipMap"),
    ("5", "Linear Mip Nearest", "MipMap interp point sampled"),
    ("6", "Linear Mip Linear", "Trilinear")
)

texture_uv_addressing_items = (
    ("0", "Disabled", ""),
    ("1", "Wrap", ""),
    ("2", "Mirror", ""),
    ("3", "Clamp", ""),
    ("4", "Border", "")
)

texture_blend_items = (
    ("0",  "Disabled",      "No blending is performed"),
    ("1",  "Zero",          "RGBA channels are set to zero"),
    ("2",  "One",           "RGBA channels are set to one"),
    ("3",  "Src Color",     "Source RGBA values"),
    ("4",  "Inv Src Color", "Inverse of source RGBA values"),
    ("5",  "Src Alpha",     "Source alpha on all channels"),
    ("6",  "Inv Src Alpha", "Inverse source alpha on all channels"),
    ("7",  "Dst Alpha",     "Destination alpha on all channels"),
    ("8",  "Inv Dst Alpha", "Inverse destination alpha on all channels"),
    ("9",  "Dst Color",     "Destination RGBA values"),
    ("10", "Inv Dst Color", "Inverse destination RGBA values"),
    ("11", "Src Alpha Sat", "Source alpha saturated")
)

class MATERIAL_PT_mchDragonMaterials(bpy.types.Panel):

    bl_idname      = "MATERIAL_PT_mchDragonMaterials"
    bl_label       = "melancholy / DragonFF - Export Material"
    bl_space_type  = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context     = "material"

    ########################################################
    def update_texture(self, context):
        if not hasattr(context, 'material'):
            return

        mat = context.material
        if not mat or not mat.node_tree:
            return

        principled = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if not principled:
            return

        image_node = None
        for link in mat.node_tree.links:
            if link.to_node == principled and link.to_socket.name == 'Base Color':
                if link.from_node.type == 'TEX_IMAGE':
                    image_node = link.from_node
                    break

        tex_name = mat.dff.tex_name

        if tex_name:
            image = bpy.data.images.get(tex_name)
            if image:
                if not image_node:
                    image_node = mat.node_tree.nodes.new(type='ShaderNodeTexImage')
                    mat.node_tree.links.new(image_node.outputs['Color'], principled.inputs['Base Color'])
                    mat.node_tree.links.new(image_node.outputs['Alpha'], principled.inputs['Alpha'])

                image_node.image = image

                tex_label, _ = extract_texture_info_from_name(tex_name)
                image_node.label = clear_extension(tex_label)
        else:
            if image_node:

                for link in list(mat.node_tree.links):
                    if link.from_node == image_node:
                        mat.node_tree.links.remove(link)

                mat.node_tree.nodes.remove(image_node)

    #######################################################
    def draw_col_menu(self, context):
        layout = self.layout
        settings = context.material.dff

        box = layout.box()
        box.label(text="Collision properties")

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Material")
        split.prop(settings, "col_mat_index", text="")

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Flags")
        split.prop(settings, "col_flags", text="")

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Brightness")
        split.prop(settings, "col_brightness", text="")

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Light")
        prop_row = split.row(align=True)
        prop_row.prop(settings, "col_day_light", text="Day")
        prop_row.prop(settings, "col_night_light", text="Night")

        layout.label(text="Collision presets are managed by DragonFF")

    #######################################################
    def draw_labelled_prop(self, row, settings, props, label, text=""):

        row.label(text=label)
        for prop in props:
            row.prop(settings, prop, text=text)

    #######################################################
    def draw_texture_prop_box(self, context, box):
        settings = context.material.dff

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Texture")

        prop_row = split.row(align=True)
        prop_row.prop_search(settings, "tex_name", bpy.data, "images", text="", icon='IMAGE_DATA')
        prop_row.operator("image.open", text="", icon='FILEBROWSER')

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Filtering")
        split.prop(settings, "tex_filters", text="")

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Addressing")

        prop_row = split.row(align=True)  
        prop_row.prop(settings, "tex_u_addr", text="")
        prop_row.prop(settings, "tex_v_addr", text="")

    #######################################################
    def draw_material_prop_box(self, context, box):
        settings = context.material.dff

        # This is for conveniently setting the base colour from the settings
        # without removing the texture node
        
        try:
            node = next((node for node in context.material.node_tree.nodes if node.type == 'BSDF_PRINCIPLED'), None)
            prop = node.inputs[0]
            prop_val = "default_value"
            
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Color")
            
            color_row = split.row()
            color_row.prop(prop, prop_val, text="")
            color_row.prop(settings, "preset_mat_cols", text="", icon="MATERIAL", icon_only=True)
            
        except Exception:
            pass

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Ambient")
        split.prop(settings, "ambient", text="")
        
        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Specular")
        split.prop(settings, "specular", text="")

        split = box.row().split(factor=0.4)
        split.alignment = 'LEFT'
        split.label(text="Diffuse")
        split.prop(settings, "diffuse", text="")

    #######################################################
    def draw_bump_map_box(self, context, box):
        settings = context.material.dff
        box.row().prop(settings, "export_bump_map")
        
        if settings.export_bump_map:
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Texture")
            split.prop(settings, "bump_map_tex", text="")
            
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Intensity")
            split.prop(settings, "bump_map_intensity", text="")
            
            self.draw_labelled_prop(
                box.row(), settings, ["bump_dif_alpha"], "Use Diffuse Alpha")

    #######################################################
    def draw_env_map_box(self, context, box):
        settings = context.material.dff
        box.row().prop(context.material.dff, "export_env_map")
        
        if settings.export_env_map:
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Texture")
            split.prop(settings, "env_map_tex", text="")

            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Coefficient")
            split.prop(settings, "env_map_coef", text="")
            
            self.draw_labelled_prop(
                box.row(), settings, ["env_map_fb_alpha"], "Use Framebuffer Alpha")

    #######################################################
    def draw_dual_tex_box(self, context, box):
        settings = context.material.dff
        box.row().prop(settings, "export_dual_tex")
        
        if settings.export_dual_tex:
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Texture")
            split.prop(settings, "dual_tex", text="")
            
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Blending")
            prop_row = split.row(align=True)
            prop_row.prop(settings, "dual_src_blend", text="")
            prop_row.prop(settings, "dual_dst_blend", text="")

    #######################################################
    def draw_uv_anim_box(self, context, box):
        settings = context.material.dff
        box.row().prop(settings, "export_animation")
        
        if settings.export_animation:
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Name")
            split.prop(settings, "animation_name", text="")

            self.draw_labelled_prop(
                box.row(), settings, ["force_dual_pass"], "Force Dual Pass")

    #######################################################
    def draw_specl_box(self, context, box):
        settings = context.material.dff
        box.row().prop(settings, "export_specular")
        
        if settings.export_specular:
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Texture")
            split.prop(settings, "specular_texture", text="")
            
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Level")
            split.prop(settings, "specular_level", text="")

    #######################################################
    def draw_refl_box(self, context, box):
        settings = context.material.dff
        box.row().prop(settings, "export_reflection")
        
        if settings.export_reflection:
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Scale")
            prop_row = split.row(align=True)
            prop_row.prop(settings, "reflection_scale_x", text="")
            prop_row.prop(settings, "reflection_scale_y", text="")
            
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Offset")
            prop_row = split.row(align=True)
            prop_row.prop(settings, "reflection_offset_x", text="")
            prop_row.prop(settings, "reflection_offset_y", text="")
            
            split = box.row().split(factor=0.4)
            split.alignment = 'LEFT'
            split.label(text="Intensity")
            split.prop(settings, "reflection_intensity", text="")
            
            #box.prop(settings, "preset_reflection_scales", text="Presets", icon="PRESET", icon_only=True)

    #######################################################
    def draw_mesh_menu(self, context):

        layout = self.layout
        settings = context.material.dff

        box = layout.box()
        box.label(text="Material Properties")
        self.draw_material_prop_box (context, box.box())
        self.draw_texture_prop_box  (context, box.box())

        box = layout.box()
        box.label(text="Material Effects")
        self.draw_bump_map_box      (context, box.box())
        self.draw_env_map_box       (context, box.box())
        self.draw_dual_tex_box      (context, box.box())
        self.draw_uv_anim_box       (context, box.box())

        box = layout.box()
        box.label(text="Rockstar Extensions")
        self.draw_refl_box          (context, box.box())
        self.draw_specl_box         (context, box.box())

    #######################################################
    # Callback function from preset_mat_cols enum
    def set_preset_color(self, context):
        try:
            color = (int(x) for x in context.material.dff.preset_mat_cols[1:-1].split(","))
            color = [i / 255 for i in color]
                
            node = next((node for node in context.material.node_tree.nodes if node.type == 'BSDF_PRINCIPLED'), None)
            node.inputs[0].default_value = color

            # Viewport color in Blender 2.8 and Material color in 2.79.
            context.material.diffuse_color = color

        except Exception as e:
            print(e)

    #######################################################
    # Callback function from preset_reflection_intensities enum
    def set_preset_reflection_intensity(self, context):
        self.reflection_intensity = float(self.preset_reflection_intensities)

    #######################################################
    # Callback function from preset_reflection_scales enum
    def set_preset_reflection_scale(self, context):
        val = float(self.preset_reflection_scales)
        self.reflection_scale_x = val
        self.reflection_scale_y = val
        self.reflection_offset_x = val

    #######################################################
    # Callback function from preset_specular_levels enum
    def set_preset_specular_level(self, context):
        self.specular_level = float(self.preset_specular_levels)

    #######################################################
    def draw(self, context):

        if not context.material or not context.material.dff:
            return
        
        if context.object.dff.type == 'COL':
            self.draw_col_menu(context)
            return

        self.draw_mesh_menu(context)

class MCHDFFMaterialProps(bpy.types.PropertyGroup):

    ambient            : bpy.props.FloatProperty  (name="Ambient Shading",   default=0.5)
    specular           : bpy.props.FloatProperty  (name="Specular Lighting", default=0.5)
    diffuse            : bpy.props.FloatProperty  (name="Diffuse Intensity", default=0.5)
    tex_name           : bpy.props.StringProperty (name="Texture", update=MATERIAL_PT_mchDragonMaterials.update_texture)
    tex_filters        : bpy.props.EnumProperty  (items=texture_filters_items, default="0")
    tex_u_addr         : bpy.props.EnumProperty  (name="", items=texture_uv_addressing_items, default="0")
    tex_v_addr         : bpy.props.EnumProperty  (name="", items=texture_uv_addressing_items, default="0")

    # Environment Map
    export_env_map     : bpy.props.BoolProperty   (name="Environment Map")
    env_map_tex        : bpy.props.StringProperty ()
    env_map_coef       : bpy.props.FloatProperty  (default=1.0)
    env_map_fb_alpha   : bpy.props.BoolProperty   ()

    # Bump Map
    export_bump_map    : bpy.props.BoolProperty   (name="Bump Map")
    bump_map_intensity : bpy.props.FloatProperty  (default=1.0)
    bump_map_tex       : bpy.props.StringProperty ()
    height_map_tex     : bpy.props.StringProperty ()  # Store internally just in case
    bump_dif_alpha     : bpy.props.BoolProperty   (name="Use Diffuse Alpha")
    
    # Dual Texture
    export_dual_tex    : bpy.props.BoolProperty   (name="Dual Texture")
    dual_tex           : bpy.props.StringProperty ()
    dual_src_blend     : bpy.props.EnumProperty  (name="", items=texture_blend_items, default="5")
    dual_dst_blend     : bpy.props.EnumProperty  (name="", items=texture_blend_items, default="6")

    # Reflection
    export_reflection    : bpy.props.BoolProperty  (name="Reflection Material")
    reflection_scale_x   : bpy.props.FloatProperty (default=1.0)
    reflection_scale_y   : bpy.props.FloatProperty (default=1.0)
    reflection_offset_x  : bpy.props.FloatProperty (default=1.0)
    reflection_offset_y  : bpy.props.FloatProperty (default=1.0)
    reflection_intensity : bpy.props.FloatProperty (default=0.1)

    # Pre-set Reflection Intensity
    preset_reflection_intensities : bpy.props.EnumProperty(
        items = ((str(key), name, desc)
                 for key, (name, desc) in presets.material_reflection_intensities.items()),
        name = "Preset Reflection Intensity",
        description = "Preset reflection intensity levels (0-50)",
        update = MATERIAL_PT_mchDragonMaterials.set_preset_reflection_intensity
    )

    # Pre-set Reflection Scale & Offset
    preset_reflection_scales : bpy.props.EnumProperty(
        items = ((str(key), name, desc)
                 for key, (name, desc) in presets.material_reflection_scales.items()),
        name = "Preset Reflection Scales",
        description = "Preset reflection offsets and scales",
        update = MATERIAL_PT_mchDragonMaterials.set_preset_reflection_scale
    )

    # Specularity
    export_specular  : bpy.props.BoolProperty(name="Specular Material")
    specular_level   : bpy.props.FloatProperty  (default=0.1)
    specular_texture : bpy.props.StringProperty ()

    # Pre-set Specular Level
    preset_specular_levels : bpy.props.EnumProperty(
        items = ((str(key), name, desc)
                 for key, (name, desc) in presets.material_specular_levels.items()),
        name = "Preset Specular Levels",
        description = "Preset specular levels",
        update = MATERIAL_PT_mchDragonMaterials.set_preset_specular_level
    )

    # Collision Data
    col_flags       : bpy.props.IntProperty(min=0, max=255)
    col_brightness  : bpy.props.IntProperty(min=0, max=255)
    col_day_light   : bpy.props.IntProperty(min=0, max=15)
    col_night_light : bpy.props.IntProperty(min=0, max=15)
    col_mat_index   : bpy.props.IntProperty(min=0, max=255)

    # UV Animation
    export_animation : bpy.props.BoolProperty   (name="UV Animation")
    animation_name   : bpy.props.StringProperty ()
    force_dual_pass  : bpy.props.BoolProperty   (name="Force Dual Pass")

    # Pre-set Material Colours
    preset_mat_cols : bpy.props.EnumProperty(
        items = ((str(key), name, desc)
                 for key, (name, desc) in presets.material_colours.items()),
        name = "Preset Material Colours",
        description = "Preset material colours",
        update = MATERIAL_PT_mchDragonMaterials.set_preset_color
    )

class MCHDFFObjectProps(bpy.types.PropertyGroup):
    type : bpy.props.EnumProperty(
        items = (
            ('OBJ', 'Object', 'Object will be exported as a mesh or a dummy'),
            ('COL', 'Collision Object', 'Object is a collision object'),
            ('SHA', 'Shadow Object', 'Object is a shadow object'),
            ('2DFX', '2DFX', 'Object is a 2D effect'),
            ('BRK', 'Breakable Object', 'Object is a breakable model'),
            ('CULL', 'CULL', 'Object is a CULL zone'),
            ('NON', "Don't export", 'Object will NOT be exported.')
        )
    )
    export_normals : bpy.props.BoolProperty(
        default=True,
        description="Whether Normals will be exported. (Disable for Map objects)"
    )
    export_split_normals : bpy.props.BoolProperty(
        default=False,
        description="Whether Custom Split Normals will be exported (Flat Shading)."
    )
    light : bpy.props.BoolProperty(
        default=True,
        description="Enable rpGEOMETRYLIGHT flag"
    )
    modulate_color : bpy.props.BoolProperty(
        default=True,
        description="Enable rpGEOMETRYMODULATEMATERIALCOLOR flag"
    )
    uv_map1 : bpy.props.BoolProperty(
        default=True,
        description="First UV Map will be exported")
    uv_map2 : bpy.props.BoolProperty(
        default=True,
        description="Second UV Map will be exported"
    )
    day_cols : bpy.props.BoolProperty(
        default=True,
        description="Whether Day Vertex Prelighting Colours will be exported"
    )
    night_cols : bpy.props.BoolProperty(
        default=True,
        description="Extra prelighting colours. (Tip: Disable export normals)"
    )
    pipeline : bpy.props.EnumProperty(
        items = (
            ('NONE', 'None', 'Export without setting a pipeline'),
            ('0x53F20098', 'Buildings', 'Refl. Building Pipleine (0x53F20098)'),
            ('0x53F2009A', 'Vehicles', 'Vehicles (0x53F2009A)'),
            (
                '0x53F2009C',
                'Night Vertex Colors',
                'Night Vertex Colors (0x53F2009C)'
            ),
            ('CUSTOM', 'Custom Pipeline', 'Set a different pipeline')
        ),
        name="Pipeline",
        description="Select the Engine rendering pipeline"
    )
    custom_pipeline : bpy.props.StringProperty(name="Custom Pipeline")
    right_to_render : bpy.props.IntProperty(
        default = 1,
        min = 0,
        description = "Right To Render value (only for skinned object)"
    )
    sky_gfx : bpy.props.BoolProperty(
        default = False,
        description = "Enable SkyGFX (Wind Shader)"
    )

class ImportMaterialHelper:

    """ Material Helper for Blender 2.7x and Blender 2.8 compatibility"""

    #######################################################
    def set_base_color(self, color):

        if self.principled:
            self.principled.base_color = [i / 255 for i in color[:3]]

            # Set Alpha
            node = self.principled.node_principled_bsdf.inputs["Base Color"]
            node.default_value[3] = color[3] / 255

            self.material.diffuse_color = [i / 255 for i in color]

        else:
            self.material.diffuse_color = [i / 255 for i in color[:3]]
            self.material.alpha = color[3] / 255

        # Set preset material colours
        color_key = tuple(color)
        if color_key in presets.material_colours:
            colours = list(presets.material_colours)
            self.material.dff["preset_mat_cols"] = colours.index(color_key)

    #######################################################
    def set_texture(self, image, label="", filters=0, uv_addressing=0):

        if self.principled:
            self.principled.base_color_texture.node_image.label = label
            self.principled.base_color_texture.image  = image


            # Connect Alpha output to Principled BSDF
            image_node      = self.principled.base_color_texture.node_image
            principled_node = self.principled.node_principled_bsdf
            node_tree       = self.principled.material.node_tree

            node_tree.links.new(image_node.outputs["Alpha"],
                                principled_node.inputs["Alpha"])

        else:
            slot               = self.material.texture_slots.add()
            slot.texture       = bpy.data.textures.new(
                name           = label,
                type           = "IMAGE"
            )
            slot.texture.image = image

        self.material.dff.tex_filters = str(filters)
        self.material.dff.tex_u_addr  = str((uv_addressing >> 4) & 0xF)
        self.material.dff.tex_v_addr  = str(uv_addressing & 0xF)

        if image:
            self.material.dff.tex_name = image.name

    #######################################################
    def set_surface_properties(self, props):

        self.material.dff.diffuse  = props.diffuse
        self.material.dff.specular = props.specular
        self.material.dff.ambient  = props.ambient

    #######################################################
    def set_environment_map(self, plugin):

        if plugin.env_map:
            self.material.dff.env_map_tex      = plugin.env_map.name

        self.material.dff.export_env_map       = True
        self.material.dff.env_map_coef         = plugin.coefficient
        self.material.dff.env_map_fb_alpha     = plugin.use_fb_alpha        

    #######################################################
    def set_dual_texture(self, plugin):

        if plugin.texture:
            self.material.dff.dual_tex         = plugin.texture.name

        self.material.dff.export_dual_tex      = True
        self.material.dff.dual_src_blend       = str(plugin.src_blend)
        self.material.dff.dual_dst_blend       = str(plugin.dst_blend)

    #######################################################
    def set_specular_material(self, plugin):

        self.material.dff.export_specular = True
        self.material.dff.specular_level = plugin.level
        self.material.dff.specular_texture = plugin.texture[:strlen(plugin.texture)].decode('ascii')

        # Set preset specular level
        level_key = round(plugin.level, 2)
        if level_key in presets.material_specular_levels:
            levels = list(presets.material_specular_levels)
            self.material.dff["preset_specular_levels"] = levels.index(level_key)

    #######################################################
    def set_reflection_material(self, plugin):

        self.material.dff.export_reflection = True

        self.material.dff.reflection_scale_x = plugin.s_x
        self.material.dff.reflection_scale_y = plugin.s_y

        self.material.dff.reflection_offset_y = plugin.o_y
        self.material.dff.reflection_offset_x = plugin.o_x

        self.material.dff.reflection_intensity = plugin.intensity

        # Set preset reflection intensities
        intensity_key = round(plugin.intensity, 2)
        if intensity_key in presets.material_reflection_intensities:
            intensities = list(presets.material_reflection_intensities)
            self.material.dff["preset_reflection_intensities"] = intensities.index(intensity_key)

        # Set preset reflection scales
        scale_key = round(plugin.s_x, 2)
        if scale_key in presets.material_reflection_scales:
            scales = list(presets.material_reflection_scales)
            self.material.dff["preset_reflection_scales"] = scales.index(scale_key)

    #######################################################
    def set_uv_animation(self, uv_anim):
        anim_data = self.material.node_tree.animation_data_create()
       
        if self.principled:
            mapping = self.principled.base_color_texture.node_mapping_get()
            mapping.vector_type = 'POINT'
            fps = bpy.context.scene.render.fps
            action = bpy.data.actions.new(uv_anim.name)
            anim_data.action = action
           
            if bpy.app.version < (4, 4, 0):
                action_fcurves = action.fcurves
            else:
                slot = action.slots.new(id_type='NODETREE', name='UV')
                anim_data.action_slot = slot
                layer = action.layers.new('UV')
                strip = layer.strips.new(type='KEYFRAME')
                channelbag = strip.channelbag(slot, ensure=True)
                action_fcurves = channelbag.fcurves
           
            fcurves = [
                action_fcurves.new(data_path=f'nodes["{mapping.name}"].inputs[2].default_value', index=2),
                action_fcurves.new(data_path=f'nodes["{mapping.name}"].inputs[3].default_value', index=0),
                action_fcurves.new(data_path=f'nodes["{mapping.name}"].inputs[3].default_value', index=1),
                None,
                action_fcurves.new(data_path=f'nodes["{mapping.name}"].inputs[1].default_value', index=0),
                action_fcurves.new(data_path=f'nodes["{mapping.name}"].inputs[1].default_value', index=1),
            ]
           
            frames_to_import = uv_anim.frames
            if len(frames_to_import) > 1:
                last = frames_to_import[-1]
                prev = frames_to_import[-2]
                if last.time > prev.time and last.uv == prev.uv:
                    frames_to_import = uv_anim.frames[:-1]
           
            for frame_idx, frame in enumerate(frames_to_import):
                for fc_idx, fc in enumerate(fcurves):
                    if not fc:
                        continue
                   
                    should_add_kp = True
                   
                    if frame_idx > 0 and frame.time == frames_to_import[frame_idx-1].time:
                        if len(fc.keyframe_points) < 2:
                            should_add_kp = False
                        else:
                            prev_kp, kp = fc.keyframe_points[-2:]
                            if prev_kp.interpolation == 'CONSTANT':
                                should_add_kp = False
                            elif prev_kp.co[1] == kp.co[1]:
                                should_add_kp = False
                                prev_kp.interpolation = 'CONSTANT'
                   
                    if should_add_kp:
                        fc.keyframe_points.add(1)
                   
                    kp = fc.keyframe_points[-1]
                    val = frame.uv[fc_idx]
                   
                    if fc_idx == 5:
                        scale_y = frame.uv[2]
                        val = 1 - (val + scale_y)
                   
                    kp.co = frame.time * fps + 1, val
                    kp.interpolation = 'LINEAR'
       
        self.material.dff.animation_name = uv_anim.name
        self.material.dff.export_animation = True

    #######################################################
    def set_user_data(self, user_data):
        self.material['dff_user_data'] = user_data.to_mem()[12:]
        
    #######################################################
    def __init__(self, material):
        self.material   = material
        self.principled = None

        # Init Principled Wrapper for Blender 2.8
        from bpy_extras.node_shader_utils import PrincipledBSDFWrapper

        self.principled = PrincipledBSDFWrapper(self.material,
                                                is_readonly=False)

        self.principled.specular    = 0
        self.principled.roughness   = 1

class material_helper:

    """ Material Helper for Blender 2.7x and 2.8 compatibility"""

    #######################################################
    def get_base_color(self):

        if self.principled:
            node = self.principled.node_principled_bsdf.inputs["Base Color"]
            return dff.RGBA._make(
                list(round(255 * x) for x in node.default_value)
            )
        alpha = round(self.material.alpha * 255)
        return dff.RGBA._make(
                    list(round(255 * x) for x in self.material.diffuse_color) + [alpha]
                )

    #######################################################
    def get_texture(self):

        texture = dff.Texture()
        texture.filters = int(self.material.dff.tex_filters)
        texture.uv_addressing = int(self.material.dff.tex_u_addr) << 4 | int(self.material.dff.tex_v_addr)

        # 2.8
        if self.principled:
            if self.principled.base_color_texture.image is not None:

                node_label = self.principled.base_color_texture.node_image.label
                image_name = self.principled.base_color_texture.image.name

                # Use node label if it is a substring of image name, else
                # use image name
                if node_label in image_name and node_label != "":
                    image_name = node_label

                texture_name, _ = extract_texture_info_from_name(image_name)
                texture.name = clear_extension(texture_name)
                return texture
            return None

        # Blender Internal
        try:
            image_name = self.material.texture_slots[0].texture.image.name
            texture_name, _ = extract_texture_info_from_name(image_name)
            texture.name = clear_extension(texture_name)
            return texture

        except BaseException:
            return None

    #######################################################
    def get_surface_properties(self):

        ambient  = self.material.dff.ambient
        specular = self.material.dff.specular
        diffuse  = self.material.dff.diffuse

        return dff.GeomSurfPro(ambient, specular, diffuse)

    #######################################################
    def get_bump_map(self):

        bump_texture = None
        height_texture = None

        if not self.material.dff.export_bump_map:
            return None

        bump_texture_name = self.material.dff.bump_map_tex
        intensity = self.material.dff.bump_map_intensity
        bump_dif_alpha = self.material.dff.bump_dif_alpha

        base_color_texture = None
        if bump_dif_alpha:
            base_color_texture = self.get_texture()

        # Create bump texture (may have empty name when use diffuse alpha is set)
        bump_texture = dff.Texture()
        bump_texture.name = bump_texture_name
        
        # If diffuse alpha is checked use material texture as heightmap
        if bump_dif_alpha and base_color_texture:
            height_texture = dff.Texture()
            height_texture.name = base_color_texture.name
        
        return dff.BumpMapFX(intensity, height_texture, bump_texture)

    #######################################################
    def get_environment_map(self):

        if not self.material.dff.export_env_map:
            return None

        texture_name = self.material.dff.env_map_tex
        coef         = self.material.dff.env_map_coef
        use_fb_alpha  = self.material.dff.env_map_fb_alpha

        texture = dff.Texture()
        texture.name = texture_name
        texture.filters = 0
        
        return dff.EnvMapFX(coef, use_fb_alpha, texture)

    #######################################################
    def get_dual_texture(self):

        if not self.material.dff.export_dual_tex:
            return None

        texture_name = self.material.dff.dual_tex
        src_blend    = int(self.material.dff.dual_src_blend)
        dst_blend    = int(self.material.dff.dual_dst_blend)

        texture = dff.Texture()
        texture.name = texture_name
        texture.filters = 0
        
        return dff.DualFX(src_blend, dst_blend, texture)

    #######################################################
    def get_specular_material(self):

        props = self.material.dff
        
        if not props.export_specular:
            return None

        return dff.SpecularMat(props.specular_level,
                               props.specular_texture.encode('ascii'))

    #######################################################
    def get_reflection_material(self):

        props = self.material.dff

        if not props.export_reflection:
            return None

        return dff.ReflMat(
            props.reflection_scale_x, props.reflection_scale_y,
            props.reflection_offset_x, props.reflection_offset_y,
            props.reflection_intensity
        )

    #######################################################
    def get_user_data(self):

        if 'dff_user_data' not in self.material:
            return None
        
        return dff.UserData.from_mem(
                self.material['dff_user_data'])
    
    #######################################################
    def get_uv_animation(self):

        # See if export_animation checkbox is checked
        if not self.material.dff.export_animation:
            return None

        # Check if mapping nodes exist
        if not self.principled or not self.principled.base_color_texture.has_mapping_node():
            return None

        # Check if animation data exists
        anim_data = self.material.node_tree.animation_data
        if not anim_data:
            return None

        # Check if action exists
        action = anim_data.action
        if not action:
            return None

        if bpy.app.version < (4, 4, 0):
            action_fcurves = action.fcurves

        else:
            # Check if action slot exists
            action_slot = anim_data.action_slot
            if not action_slot:
                return None

            channelbag = anim_utils.action_get_channelbag_for_slot(action, action_slot)
            action_fcurves = channelbag.fcurves

        fps = bpy.context.scene.render.fps

        mapping = self.principled.base_color_texture.node_mapping_get()
        data_path_offset = {
            f'nodes["{mapping.name}"].inputs[2].default_value': 0,  # rot z
            f'nodes["{mapping.name}"].inputs[3].default_value': 1,  # scale x/y
            f'nodes["{mapping.name}"].inputs[1].default_value': 4,  # pos x/y
        }

        all_times = set()
        keyframe_data = {}

        for curve in action_fcurves:
            if curve.data_path not in data_path_offset:
                continue

            offset = data_path_offset[curve.data_path]
            if offset == 0 and curve.array_index != 2:
                continue

            if curve.array_index > 1:
                continue

            for keyframe in curve.keyframe_points:
                time = keyframe.co[0] / fps
                all_times.add(time)
                interp = keyframe.interpolation

                if time not in keyframe_data or interp == 'CONSTANT':
                    keyframe_data[time] = interp

        if not all_times:
            return None

        sorted_times = sorted(all_times)
        time_offset = sorted_times[0]
        shifted_times = [t - time_offset for t in sorted_times]

        def get_uv_at(time):
            frame = time * fps
            uv = [0.0, 1.0, 1.0, 0.0, 0.0, 0.0]
            for curve in action_fcurves:
                if curve.data_path not in data_path_offset:
                    continue

                offset = data_path_offset[curve.data_path]

                if offset == 0 and curve.array_index != 2:
                    continue

                if curve.array_index > 1:
                    continue

                idx = offset + curve.array_index if offset != 0 else 0
                uv[idx] = curve.evaluate(frame)
            return uv

        time_values = {}

        for i, shifted_t in enumerate(shifted_times):
            original_t = sorted_times[i]
            time_values[shifted_t] = get_uv_at(original_t)

        interp_data = {}

        for i, shifted_t in enumerate(shifted_times):
            original_t = sorted_times[i]
            interp = keyframe_data.get(original_t, 'LINEAR')
            interp_data[shifted_t] = 'CONSTANT' if interp == 'CONSTANT' else 'LINEAR'

        anim = dff.UVAnim()
        anim.name = self.material.dff.animation_name
        uv_0 = time_values[0]
        flipped_0 = [uv_0[0], uv_0[1], uv_0[2], 0.0, uv_0[4], 1 - (uv_0[5] + uv_0[2])]
        anim.frames.append(dff.UVFrame(0.0, flipped_0, -1))
        prev_idx = 0

        for i in range(len(shifted_times) - 1):
            next_t = shifted_times[i + 1]
            interp = interp_data[shifted_times[i]]
            prev_uv = anim.frames[-1].uv
            current_uv = time_values[next_t]
            flipped_current = [current_uv[0], current_uv[1], current_uv[2], 0.0, current_uv[4], 1 - (current_uv[5] + current_uv[2])]

            if interp == 'CONSTANT':
                anim.frames.append(dff.UVFrame(next_t, list(prev_uv), prev_idx))
                prev_idx = len(anim.frames) - 1
                anim.frames.append(dff.UVFrame(next_t, flipped_current, prev_idx))
                prev_idx = len(anim.frames) - 1
            else:
                anim.frames.append(dff.UVFrame(next_t, flipped_current, prev_idx))
                prev_idx = len(anim.frames) - 1

        if anim.frames:
            anim.duration = shifted_times[-1]

        is_fully_constant = len(shifted_times) >= 2 and all(v == 'CONSTANT' for v in interp_data.values())

        if is_fully_constant:
            num_intervals = len(shifted_times) - 1
            mean_delta = shifted_times[-1] / num_intervals
            extra_t = shifted_times[-1] + mean_delta
            last_uv = anim.frames[-1].uv
            anim.frames.append(dff.UVFrame(extra_t, list(last_uv), prev_idx))
            anim.duration = extra_t

        return anim

    #######################################################
    def __init__(self, material):
        self.material = material
        self.principled = None

        from bpy_extras.node_shader_utils import PrincipledBSDFWrapper

        self.principled = PrincipledBSDFWrapper(self.material,
                                                is_readonly=False)

class MaterialExporter:
    @staticmethod
    def generate_material_list(obj):
            materials = []
            self = MaterialExporter
    
            for b_material in obj.data.materials:
    
                material = dff.Material()
    
                if b_material:
                    helper = material_helper(b_material)
    
                    material.color              = helper.get_base_color()
                    material.surface_properties = helper.get_surface_properties()
    
                    texture = helper.get_texture()
                    if texture:
                        material.textures.append(texture)
    
                    # Materials
                    material.add_plugin('bump_map', helper.get_bump_map())
                    material.add_plugin('env_map', helper.get_environment_map())
                    material.add_plugin('dual', helper.get_dual_texture())
                    material.add_plugin('spec', helper.get_specular_material())
                    material.add_plugin('refl', helper.get_reflection_material())
                    material.add_plugin('udata', helper.get_user_data())
    
                    anim = helper.get_uv_animation()
                    if anim:
                        material.add_plugin('uv_anim', anim.name)
                        self.dff.uvanim_dict.append(anim)
    
                    # Create a dummy uv anim to apply to the second uv channel to force dual pass blending
                    if b_material.dff.force_dual_pass and b_material.dff.export_dual_tex and b_material.dff.dual_tex:
                        dummy_anim = dff.UVAnim()
                        dummy_anim.name = "DragonFF"
                        dummy_anim.node_to_uv[0] = 1
                        dummy_anim.duration = 1.0
                        dummy_anim.frames = [
                            dff.UVFrame(0.0, [0.0, 1.0, 1.0, 0.0, 0.0, 0.0], -1),
                            dff.UVFrame(1.0, [0.0, 1.0, 1.0, 0.0, 0.0, 0.0],  0)
                        ]
    
                        material.add_plugin('uv_anim', dummy_anim.name)
                        self.dff.uvanim_dict.append(dummy_anim)
    
                else:
                    # Geometry faces can be assigned to empty material slot, so a basic material should be created
                    material.color              = dff.RGBA._make((255, 255, 255, 255))
                    material.surface_properties = dff.GeomSurfPro(1.0, 1.0, 1.0)
    
                materials.append(material)
    
            return materials
