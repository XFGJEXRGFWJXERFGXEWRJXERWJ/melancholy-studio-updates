"""Bridge DragonFF's material system to melancholy's preserved 32-bone DFF."""
import bpy
import struct, base64, json
import numpy as np
from mathutils.kdtree import KDTree
from . import dragon_materials as dragon
from .gtaLib import dff

_owned = []


@bpy.app.handlers.persistent
def initialize_loaded_projects(*_):
    for o in bpy.data.objects:
        if o.type != 'MESH' or 'mch_meta' not in o or o.mode == 'EDIT': continue
        try:
            document=dff.dff();document.load_memory(base64.b64decode(bpy.data.texts[o['mch_source']].as_string()))
            initialize(o,document,json.loads(o['mch_meta'])['axes'])
        except Exception as error:
            print('melancholy material migration:', o.name, error)


class OBJECT_PT_mchLighting(bpy.types.Panel):
    bl_label = 'melancholy / DragonFF - Rendering'
    bl_idname = 'OBJECT_PT_mchLighting'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'object'

    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'MESH' and 'mch_meta' in context.object

    def draw(self, context):
        p = context.object.dff
        for field in ('light', 'modulate_color', 'export_normals', 'export_split_normals', 'day_cols', 'night_cols', 'uv_map1', 'uv_map2', 'pipeline'):
            self.layout.prop(p, field)
        if p.pipeline == 'CUSTOM': self.layout.prop(p, 'custom_pipeline')
        self.layout.prop(p, 'right_to_render')
        self.layout.prop(p, 'sky_gfx')


def register():
    for cls in (dragon.MCHDFFMaterialProps, dragon.MCHDFFObjectProps): bpy.utils.register_class(cls)
    for typ, cls in ((bpy.types.Material, dragon.MCHDFFMaterialProps), (bpy.types.Object, dragon.MCHDFFObjectProps)):
        if not hasattr(typ, 'dff'):
            typ.dff = bpy.props.PointerProperty(type=cls)
            _owned.append((typ, cls))
    bpy.utils.register_class(dragon.MATERIAL_PT_mchDragonMaterials)
    bpy.utils.register_class(OBJECT_PT_mchLighting)
    bpy.app.handlers.load_post.append(initialize_loaded_projects)


def unregister():
    if initialize_loaded_projects in bpy.app.handlers.load_post: bpy.app.handlers.load_post.remove(initialize_loaded_projects)
    bpy.utils.unregister_class(OBJECT_PT_mchLighting)
    bpy.utils.unregister_class(dragon.MATERIAL_PT_mchDragonMaterials)
    for typ, cls in _owned:
        prop = typ.bl_rna.properties.get('dff')
        if prop and prop.fixed_type.identifier == cls.__name__: delattr(typ, 'dff')
    _owned.clear()
    for cls in (dragon.MCHDFFObjectProps, dragon.MCHDFFMaterialProps): bpy.utils.unregister_class(cls)


def initialize(o, document, axes, restore_colors=False):
    """Migrate older packed projects without overwriting explicitly edited settings."""
    g = document.clumps[0].geometry_list[0]
    for i, mat in enumerate(o.data.materials):
        if not mat or mat.get('mch_material_ready') or i >= len(g.materials): continue
        source = g.materials[i]
        props = mat.dff
        helper = dragon.ImportMaterialHelper(mat)
        surface = source.surface_properties or g.surface_properties
        if surface:
            for field in ('ambient', 'specular', 'diffuse'):
                if not props.is_property_set(field): setattr(props, field, getattr(surface, field))
        node = helper.principled.node_principled_bsdf
        default_color=np.array(node.inputs['Base Color'].default_value)
        if not mat.get('mch_preserve_base_color') and (np.allclose(default_color,(1,1,1,1)) or np.allclose(default_color,(.8,.8,.8,1))): helper.set_base_color(source.color)
        if source.textures:
            t = source.textures[0]
            for field, value in [('tex_filters', str(t.filters)), ('tex_u_addr', str(t.uv_addressing >> 4)), ('tex_v_addr', str(t.uv_addressing & 15))]:
                if not props.is_property_set(field): setattr(props, field, value)
            if not props.is_property_set('tex_name'):
                # Assign without the UI callback: the packed image node is already connected.
                props['tex_name'] = helper.principled.base_color_texture.image.name if helper.principled.base_color_texture.image else t.name
            if helper.principled.base_color_texture.image: helper.principled.base_color_texture.node_image.label = t.name
        for plugin, flag, method in [('env_map','export_env_map','set_environment_map'), ('dual','export_dual_tex','set_dual_texture'), ('spec','export_specular','set_specular_material'), ('refl','export_reflection','set_reflection_material')]:
            if source.plugins.get(plugin) and not props.is_property_set(flag): getattr(helper, method)(source.plugins[plugin][0])
        if source.plugins.get('bump_map') and not props.is_property_set('export_bump_map'):
            b = source.plugins['bump_map'][0]; props.export_bump_map = True; props.bump_map_intensity = b.intensity
            props.bump_map_tex = b.bump_map.name if b.bump_map else ''; props.height_map_tex = b.height_map.name if b.height_map else ''; props.bump_dif_alpha = bool(b.height_map and b.bump_map)
        if source.plugins.get('udata') and 'dff_user_data' not in mat: helper.set_user_data(source.plugins['udata'][0])
        if source.plugins.get('uv_anim') and not props.is_property_set('export_animation'):
            anim = next((a for a in document.uvanim_dict if a.name == source.plugins['uv_anim'][0]), None)
            if anim: helper.set_uv_animation(anim)
        mat['mch_material_ready'] = True
    if o.get('mch_render_ready'): return
    p = o.dff
    for field, value in [('light', bool(g.flags & 32)), ('modulate_color', bool(g.flags & 64)), ('export_normals', bool(g.has_normals)), ('day_cols',bool(g.prelit_colors)), ('night_cols',bool(g.extensions.get('extra_vert_color')))]:
        if not p.is_property_set(field): setattr(p, field, value)
    atomic = document.clumps[0].atomic_list[0]
    if not p.is_property_set('pipeline'):
        pipeline = atomic.extensions.get('pipeline')
        if pipeline is None: p.pipeline = 'NONE'
        elif str(hex(pipeline)).upper().replace('0X','0x') in {'0x53F20098','0x53F2009A','0x53F2009C'}: p.pipeline = '0x%08X' % pipeline
        else: p.pipeline = 'CUSTOM'; p.custom_pipeline = hex(pipeline)
    if not p.is_property_set('right_to_render'): p.right_to_render = getattr(atomic.extensions.get('right_to_render'), 'value2', 1)
    if not p.is_property_set('sky_gfx'): p.sky_gfx = bool(atomic.extensions.get('sky_gfx'))
    if restore_colors and not o.data.color_attributes:
        # Only an explicit DFF import brings in its original colors. An empty
        # saved project is authoritative: loading/exporting must not recreate them.
        tree = KDTree(len(g.vertices))
        for i, v in enumerate(g.vertices): tree.insert(v, i)
        tree.balance()
        basis = np.array([v.co[:] for v in o.data.shape_keys.key_blocks['Basis'].data]) @ np.array(axes)
        nearest = [tree.find(v)[1] for v in basis]
        layers = [('Day', g.prelit_colors)]
        night = g.extensions.get('extra_vert_color')
        if night and night.colors: layers.append(('Night', night.colors))
        for name, colors in layers:
            if not colors: continue
            attr = o.data.color_attributes.new(name=name, type='BYTE_COLOR', domain='POINT')
            for i, j in enumerate(nearest): attr.data[i].color_srgb = [x / 255 for x in colors[j]]
    o['mch_render_ready'] = True


def corner_colors(mesh, vi, li):
    values = []
    for layer in list(mesh.color_attributes)[:2]:
        entry = layer.data[li if layer.domain == 'CORNER' else vi]
        values.append(tuple(round(max(0, min(1, x)) * 255) for x in entry.color_srgb))
    return values


def export_state(o, raw):
    """Write actual DragonFF material/plugin data, geometry flags and atomics."""
    document = dff.dff(); document.load_memory(raw)
    dff.Sections.library_id=struct.unpack_from('<I',raw,8)[0]
    g = document.clumps[0].geometry_list[0]
    dragon.MaterialExporter.dff = document
    g.materials = dragon.MaterialExporter.generate_material_list(o)
    material_data = g.material_list_to_mem()
    p = o.dff
    pipeline = None if p.pipeline == 'NONE' else int(p.custom_pipeline if p.pipeline == 'CUSTOM' else p.pipeline, 0)
    if pipeline is not None and not 0 <= pipeline <= 0xffffffff: raise ValueError('Pipeline must be uint32')
    def chunks(data):
        at = 0
        while at < len(data):
            typ, size, ver = struct.unpack_from('<III', data, at)
            yield typ, data[at+12:at+12+size], ver
            at += 12 + size
    def chunk(typ, body, ver): return struct.pack('<III', typ, len(body), ver) + body
    def walk(data, parent=0):
        result = bytearray()
        for typ, body, ver in chunks(data):
            if typ == 8 and parent == 15:
                result += material_data; continue
            if typ == 43 and parent == 0: continue
            if typ in (16, 26, 15, 20): body = walk(body, typ)
            elif parent == 15 and typ == 1:
                flags, nt, n, nm = struct.unpack_from('<4I', body)
                start = 28 if dff.Sections.get_rw_version(ver) < 0x34000 else 16
                if flags & 8 and not p.day_cols: body = body[:start] + body[start+n*4:]; flags &= ~8
                uvcount = (flags >> 16) & 255 or (2 if flags & 128 else 1 if flags & 4 else 0)
                morph = start + (n*4 if flags & 8 else 0) + uvcount*n*8 + nt*8
                hasv, hasn = struct.unpack_from('<II', body, morph+16)
                if hasn and not p.export_normals:
                    off = morph+24+n*12*bool(hasv);body = body[:morph+20] + struct.pack('<I',0) + body[morph+24:off] + body[off+n*12:]
                flags = (flags & ~(32|64|16)) | (32 if p.light else 0) | (64 if p.modulate_color else 0) | (16 if p.export_normals else 0)
                body = struct.pack('<I', flags) + body[4:]
            elif parent == 20 and typ == 3:
                managed = {31, 288, 39056115, 60909}
                body = b''.join(chunk(t,b,v) for t,b,v in chunks(body) if t not in managed)
                body += chunk(31, struct.pack('<II', 0x116, p.right_to_render), ver)
                if g._hasMatFX: body += chunk(288, struct.pack('<I',1), ver)
                if pipeline is not None: body += chunk(39056115, struct.pack('<I',pipeline), ver)
                if p.sky_gfx: body += chunk(60909,b'\x01',ver)
            result += chunk(typ, body, ver)
        return bytes(result)
    result = walk(raw)
    if document.uvanim_dict: result = document.write_uv_dict() + result
    return result
