"""Model resources, not user settings. Pure Python / numpy; also used by tests."""
import json,struct,hashlib,math
from pathlib import Path
import numpy as np
from .gtaLib.dff import dff,Sections
HEADER=2232;CONFIG=1776;CHANNELS=16
TAGS=[0,1,2,3,4,5,8,6,7,31,32,33,34,35,36,21,22,23,24,25,26,302,301,201,41,42,43,44,51,52,53,54]
SPARE=(6,7,8,21,22,23)
def fnv(data):
 h=2166136261
 for b in data:h=((h^b)*16777619)&0xffffffff
 return h
def text(value,n):
 a=str(value).encode('utf8')
 if len(a)>=n:raise ValueError('Name too long: '+str(value))
 return a+bytes(n-len(a))
def read_dff(path):
 d=dff();d.load_file(str(path))
 if len(d.clumps)!=1 or len(d.clumps[0].geometry_list)!=1:raise ValueError('One skinned geometry per model is required')
 c=d.clumps[0];g=c.geometry_list[0];s=g.extensions.get('skin')
 if not s or s.num_bones!=32:raise ValueError('Use the existing 32-bone SA skeleton; do not add bones')
 return d,c,g,s
def normalize(ids,weights):
 ids=np.asarray(ids,dtype=np.uint8);w=np.asarray(weights,dtype=np.float64)
 if ids.shape!=w.shape or ids.shape[1]!=4 or np.any(ids>=32) or not np.isfinite(w).all() or (w<0).any() or (w.sum(axis=1)<1e-8).any():raise ValueError('Invalid skeletal weights')
 return ids,w/w.sum(axis=1)[:,None]
def normals(v,t):
 out=np.zeros_like(v);cross=np.cross(v[t[:,1]]-v[t[:,0]],v[t[:,2]]-v[t[:,0]])
 for k in range(3):np.add.at(out,t[:,k],cross)
 return out/np.maximum(1e-8,np.linalg.norm(out,axis=1))[:,None]
def patch_dff(raw,vertices,normal,ids,weights,topology=None):
 v=np.asarray(vertices,dtype='<f4');normal=np.asarray(normal,dtype='<f4');ids,w=normalize(ids,weights);w=np.asarray(w,dtype='<f4');changes=[0,0]
 old_count=[None]
 def walk(data,parent=0):
  result=bytearray();pos=0
  while pos<len(data):
   typ,size,ver=struct.unpack_from('<III',data,pos);end=pos+12+size
   if end>len(data):raise ValueError('Truncated DFF chunk')
   part=data[pos+12:end]
   if typ in (0x10,0x1a,0xf) or (typ==3 and parent==0xf):part=walk(part,typ)
   elif parent==0xf and typ==1:
    flags,nt,n,nm=struct.unpack_from('<4I',part)
    old_count[0]=n
    if (topology is None and n!=len(v)) or nm!=1 or flags&0x1000000:raise ValueError('Native / multi-morph geometry unsupported')
    start=28 if Sections.get_rw_version(ver)<0x34000 else 16
    if topology is not None:
     tri,materials,uv,colors=topology[:4]
     newflags=(flags & ~(1|4|8|128|0xff0000))|2|16
     if colors is not None:newflags|=8
     if len(uv):newflags|=(4 if len(uv)==1 else 128)|(len(uv)<<16)
     center=(v.min(axis=0)+v.max(axis=0))*.5;radius=float(np.linalg.norm(v-center,axis=1).max())
     faces=np.column_stack((tri[:,1],tri[:,0],materials,tri[:,2])).astype('<u2')
     color_data=np.asarray(colors,dtype='u1').tobytes() if colors is not None else b''
     part=struct.pack('<4I',newflags,len(tri),len(v),1)+part[16:start]+color_data+np.asarray(uv,dtype='<f4').tobytes()+faces.tobytes()+struct.pack('<4fII',*center,radius,1,1)+v.tobytes()+normal.tobytes()
     changes[0]+=1
     result+=struct.pack('<III',typ,len(part),ver)+part;pos=end;continue
    uvcount=(flags>>16)&255
    if not uvcount:uvcount=2 if flags&128 else 1 if flags&4 else 0
    morph=start+(n*4 if flags&8 else 0)+uvcount*n*8+nt*8;hasv,hasn=struct.unpack_from('<II',part,morph+16);oldend=morph+24+n*12*(bool(hasv)+bool(hasn))
    center=(v.min(axis=0)+v.max(axis=0))*.5;radius=float(np.linalg.norm(v-center,axis=1).max())
    output_normal=normal.tobytes()
    if hasv and hasn:
     oldv=np.frombuffer(part,dtype='<f4',count=n*3,offset=morph+24).reshape(n,3)
     if np.max(np.abs(oldv-v))<1e-7:output_normal=part[morph+24+n*12:morph+24+n*24]
    part=struct.pack('<I',flags|16)+part[4:morph]+struct.pack('<4fII',*center,radius,1,1)+v.tobytes()+output_normal+part[oldend:];changes[0]+=1
   elif parent==3 and typ==0x116:
    bones,used,maxw=struct.unpack_from('<3B',part)
    if bones!=32:raise ValueError('Skeleton changed')
    base=4+used;matrix=base+old_count[0]*20
    if used:matrices=part[matrix:matrix+32*64];tail=part[matrix+32*64:]
    else:matrices=b''.join(part[matrix+i*68+4:matrix+(i+1)*68] for i in range(32));tail=bytes(12)
    usedbones=sorted(set(int(i) for row,ws in zip(ids,w) for i,x in zip(row,ws) if x>0));maxw=int((w>0).sum(axis=1).max())
    part=struct.pack('<4B',32,len(usedbones),maxw,0)+bytes(usedbones)+ids.tobytes()+w.tobytes()+matrices+tail;changes[1]+=1
   elif parent==3 and topology is not None:
    if typ==0x50e:
     tri,materials,_,_=topology[:4];groups={}
     for face,material in zip(tri,materials):groups.setdefault(int(material),[]).extend(map(int,face))
     part=struct.pack('<3I',0,len(groups),len(tri)*3)
     for material,indices in groups.items():part+=struct.pack('<2I',len(indices),material)+np.asarray(indices,dtype='<u4').tobytes()
    elif typ==0x253f2f9:
     pos=end;continue # Regenerated after geometry extension traversal below.
    elif typ==0x253f2fd and part==bytes(4):pass # Disabled breakable marker, no vertex references.
    else:raise ValueError('Topology rebuild cannot preserve geometry extension '+hex(typ))
   result+=struct.pack('<III',typ,len(part),ver)+part;pos=end
  if parent==3 and topology is not None and len(topology)>5 and topology[5] is not None:
   night=struct.pack('<I',1)+np.asarray(topology[5],dtype='u1').tobytes();result+=struct.pack('<III',0x253f2f9,len(night),ver)+night
  return bytes(result)
 out=walk(raw)
 if changes!=[1,1]:raise ValueError('Expected exactly one geometry and skin')
 return out
def default_base():
 b=bytearray(208);struct.pack_into('<I',b,0,1)
 for o in (4,28):struct.pack_into('<6f',b,o,45,9,.8,.2,1.5,.5)
 for o in (52,88):struct.pack_into('<I8f',b,o,1,1.2,55,8,.85,.022,.7,.9,1.1)
 struct.pack_into('<3I10f',b,124,1,1,1,3,6,.09,.035,.16,.1,3,.6,.4,.1)
 struct.pack_into('<I7f',b,176,1,.2,3,1.2,.5,1,.28,.4)
 return bytes(b)
def config_bytes(meta):
 b=bytearray(bytes.fromhex(meta.get('base',default_base().hex())))
 if len(b)!=208:raise ValueError('Invalid base settings')
 if not np.isfinite(np.frombuffer(b,dtype='<f4')).all():raise ValueError('Nonfinite preset parameter')
 if any(struct.unpack_from('<I',b,at)[0] not in (0,1) for at in (0,52,88,124,128,132,176)):raise ValueError('Enable fields must be 0 or 1')
 for at in (52,88):
  q=struct.unpack_from('<I8f',b,at);ranges=[(.2,3),(15,250),(2,50),(0,2),(0,.04),(0,1.5),(0,1.5),(0,1.5)]
  if any(not lo-1e-7<=x<=hi+1e-7 for x,(lo,hi) in zip(q[1:],ranges)):raise ValueError('Body preset outside game slider limits')
 q=struct.unpack_from('<3I10f',b,124);ranges=[(.3,20),(q[3],30),(.03,.6),(0,.6),(.03,1),(.02,.6),(0,5),(.03,3),(0,1),(.01,30)]
 if any(not lo-1e-7<=x<=hi+1e-7 for x,(lo,hi) in zip(q[3:],ranges)):raise ValueError('Eye preset outside game slider limits')
 q=struct.unpack_from('<I7f',b,176);ranges=[(.02,2),(0,15),(.03,5),(0,1),(0,1),(0,1),(0,1)]
 if any(not lo-1e-7<=x<=hi+1e-7 for x,(lo,hi) in zip(q[1:],ranges)):raise ValueError('Blush preset outside game slider limits')
 for i in range(CHANNELS):
  c=meta['channels'][i];mode=int(c.get('mode',2));bone=int(c.get('bone',-1));anchor=int(c.get('anchor',5));motion=c.get('motion',[45,9,.8,.2,1.5,.5]);pivot=c.get('pivot',[0,0,0]);tip=c.get('tip',[0,0,-.3])
  if mode not in (0,1,2) or anchor not in range(32) or (mode==1 and (bone not in SPARE or bone==anchor)):raise ValueError('Invalid channel bone / anchor')
  values=motion+pivot+tip
  if not np.isfinite(values).all():raise ValueError('Nonfinite channel setting')
  if not (5<=motion[0]<=160 and 2<=motion[1]<=40 and 0<=motion[2]<=2 and 0<=motion[3]<=1 and 0<=motion[4]<=5 and 0<=motion[5]<=.7):raise ValueError('Channel parameter outside limits')
  if mode!=2 and not .005<=np.linalg.norm(tip)<=3:raise ValueError('Channel lever must be 0.005 .. 3 metres')
  b+=struct.pack('<3i12f',mode,bone,anchor,*values)+text(c.get('name','Channel '+str(i+1)),32)
 b+=bytes(96) # Empty override: a renamed profile file updates the menu label.
 assert len(b)==CONFIG
 return bytes(b)
def write_profile(path,meta,vertices,triangles,ids,weights,blink,squint,body,hair,cheek,protect):
 v=np.asarray(vertices,dtype=float);tri=np.asarray(triangles,dtype=int);ids,w=normalize(ids,weights);n=len(v)
 blink=np.asarray(blink);squint=np.asarray(squint);body=np.clip(body,0,1);hair=np.clip(hair,0,1);cheek=np.clip(cheek,0,1);protect=np.clip(protect,0,1)
 if len(v)>100000 or len(tri)>200000:raise ValueError('Model too large')
 if not all(np.isfinite(a).all() for a in (v,blink,squint,body,hair,cheek,protect)):raise ValueError('Nonfinite weights / coordinates')
 guarded=(protect>0)|(np.linalg.norm(blink,axis=1)>1e-6)|(np.linalg.norm(squint,axis=1)>1e-6);hair[guarded,:]=0;body[guarded,:]=0
 for i,c in enumerate(meta['channels']):
  if c.get('mode',2)!=1:continue
  affected=((ids==c['bone'])&(w>1e-6)).any(axis=1)
  if not affected.any() or np.any(affected&((hair[:,i]<=0)|guarded)):raise ValueError('Channel %d: bone affects eyes / vertices outside its painted zone, or has no weights'%(i+1))
  if any(j!=i and other.get('mode')==1 and other['bone']==c['bone'] for j,other in enumerate(meta['channels'])):raise ValueError('One bone cannot drive two channels')
  if any(other.get('mode')==1 and other['bone']==c['anchor'] for other in meta['channels']):raise ValueError('Anchor cannot be a physics-controlled bone')
 nb=normals(v+blink,tri)-normals(v,tri);ns=normals(v+squint,tri)-normals(v,tri)
 active=np.where((np.linalg.norm(blink,axis=1)>1e-9)|(np.linalg.norm(squint,axis=1)>1e-9)|(body.max(axis=1)>0)|(hair.max(axis=1)>0)|(cheek>0)|(protect>0))[0]
 if not 1<=len(active)<=20000:raise ValueError('Need 1 .. 20000 active vertices')
 h=bytearray(struct.pack('<10I3i',0x3348434d,2,0,0,fnv(meta['key'].encode()),n,len(tri),32,len(active),meta.get('flags',31),meta.get('head',5),meta.get('breast_anchor',3),meta.get('butt_anchor',1)))
 h+=text(meta['key'],64)+text(meta['name'],128)+np.asarray(meta.get('axes',np.eye(3)),dtype='<f4').tobytes()+np.asarray(meta.get('centers',[[-.08,-.08,.42],[.08,-.08,.42],[-.08,.09,0],[.08,.09,0]]),dtype='<f4').tobytes()+struct.pack('<32i',*meta.get('tags',TAGS))+config_bytes(meta)
 assert len(h)==HEADER
 for row,ws in zip(ids,w):h+=struct.pack('<4B4f',*row,*ws)
 h+=v.astype('<f4').tobytes()
 for i in active:h+=struct.pack('<I37f',int(i),*v[i],*blink[i],*squint[i],*nb[i],*ns[i],*body[i],*hair[i],float(cheek[i]),float(protect[i]))
 struct.pack_into('<I',h,8,len(h));struct.pack_into('<I',h,12,fnv(h[16:]));Path(path).write_bytes(h)
 return len(active)
def read_profile(path):
 data=Path(path).read_bytes();a=struct.unpack_from('<10I3i',data)
 if a[0]!=0x3348434d or a[1] not in (1,2) or a[2]!=len(data) or a[3]!=fnv(data[16:]):raise ValueError('Invalid profile checksum / version')
 z=lambda x:x.split(b'\0')[0].decode('utf8')
 meta=dict(key=z(data[52:116]),name=z(data[116:244]),flags=a[9],head=a[10],breast_anchor=a[11],butt_anchor=a[12],axes=np.frombuffer(data,dtype='<f4',count=9,offset=244).reshape(3,3).tolist(),centers=np.frombuffer(data,dtype='<f4',count=12,offset=280).reshape(4,3).tolist(),tags=list(struct.unpack_from('<32i',data,328)),base=data[456:664].hex(),channels=[])
 for i in range(16):
  at=664+i*92;q=struct.unpack_from('<3i12f',data,at);meta['channels'].append(dict(mode=q[0],bone=q[1],anchor=q[2],motion=list(q[3:9]),pivot=list(q[9:12]),tip=list(q[12:15]),name=z(data[at+60:at+92])))
 dtype=np.dtype([('index','<u4'),('values','<f4',(37,))]);mesh=np.frombuffer(data,dtype=dtype,count=a[8],offset=HEADER+a[5]*(32 if a[1]==2 else 20))
 return meta,mesh,a[5],a[6]
